#!/bin/bash
# THE 10x DEVELOPER MEGA-SUITE v2.0
# Features: 9 Tools + Auto-Logging

LOG_FILE="dev_prompt_history.txt"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

clear
echo "=========================================="
echo "      10x DEV MEGA-COMMAND CENTER         "
echo "=========================================="
echo "1) Senior Code Reviewer         6) SQL Schema Generator"
echo "2) Chain-of-Thought Debugger    7) Unit Test Writer"
echo "3) System Architecture Builder  8) Git Commit Message Gen"
echo "4) Instant Doc-Gen (README)     9) Regex Pattern Maker"
echo "5) View History                 10) Exit"
echo "------------------------------------------"
read -p "Select a tool [1-10]: " choice

case $choice in
  1) read -p "Language: " lang; RESULT="Act as a Senior Staff Engineer. Review this $lang code for security and performance. [PASTE CODE]" ;;
  2) read -p "Error: " bug; read -p "Stack: " stack; RESULT="Act as an expert $stack debugger. Use Chain-of-Thought to solve: $bug" ;;
  3) read -p "App Idea: " app; RESULT="Act as a Software Architect. Design a full system spec for: $app" ;;
  4) read -p "Updates: " update; RESULT="Act as a Technical Writer. Create a professional README for: $update" ;;
  5) echo -e "\n--- HISTORY ---\n"; [ -f "$LOG_FILE" ] && cat "$LOG_FILE" || echo "Empty."; exit ;;
  6) read -p "Table Description: " desc; RESULT="Act as a Database Admin. Write optimized SQL DDL (Create Table) for: $desc" ;;
  7) read -p "Function/Logic: " logic; RESULT="Act as a QA Engineer. Write 5 comprehensive unit tests for this logic: $logic" ;;
  8) read -p "What did you change? " change; RESULT="Act as a Git expert. Write a professional 'Conventional Commit' message for: $change" ;;
  9) read -p "Describe the text to match: " reg; RESULT="Act as a Regex expert. Create a regular expression to match $reg. Explain how it works." ;;
  10) echo "Exiting..."; exit ;;
  *) echo "Invalid."; exit ;;
esac

# Output to screen
echo -e "\n--- COPY THIS PROMPT ---\n"
echo "$RESULT"

# Save to file
echo -e "------------------------------------------\nDATE: $DATE\nPROMPT: $RESULT\n------------------------------------------" >> "$LOG_FILE"

echo -e "\n[✔] Saved to $LOG_FILE"
echo "=========================================="
