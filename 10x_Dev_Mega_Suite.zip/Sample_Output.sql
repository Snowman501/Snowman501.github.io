CREATE TABLE users (
    id            BIGINT          NOT NULL GENERATED ALWAYS AS IDENTITY,
    email         VARCHAR(255)    NOT NULL,
    password_hash CHAR(60)        NOT NULL,
    created_at    TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_users         PRIMARY KEY (id),
    CONSTRAINT uq_users_email   UNIQUE      (email),
    CONSTRAINT ck_users_email   CHECK       (email ~* '^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$')
);

-- Index for email lookups (login, password reset, etc.)
CREATE INDEX idx_users_email ON users (email);

-- Index for time-based queries (reporting, user growth, etc.)
CREATE INDEX idx_users_created_at ON users (created_at);