==========================================
   10x DEV MEGA-COMMAND CENTER v2.0
==========================================

--- HOW TO RUN ---
1. Open your Linux terminal.
2. Navigate to this folder: cd ~/Desktop/dev-tool
3. Give the script permission: chmod +x dev-suite-pro.sh
4. Launch the tool: ./dev-suite-pro.sh

--- HOW TO USE ---
1. Select a tool from the menu (1-10).
2. Answer the brief prompts about your code or error.
3. Highlight and COPY the "Super-Prompt" generated on your screen.
4. PASTE that prompt into ChatGPT, Claude, or Gemini for expert results.

--- FILE GUIDE ---
* dev-suite-pro.sh: The interactive prompt generator.
* dev_prompt_history.txt: Automatically logs your past prompts.
* Sample_Output.sql: A real example of the high-quality code this tool produces.
==========================================